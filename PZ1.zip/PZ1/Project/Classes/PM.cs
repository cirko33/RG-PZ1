﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Classes
{
    public class PM
    {
        public static double MinX { get; set; }
        public static double MaxX { get; set; }
        public static double MinY { get; set; }
        public static double MaxY { get; set; }
        public static double OffsetX { get; set; }
        public static double OffsetY { get; set; }
        public static int Size { get; set; }
        public static int MoveX { get; set; }
        public static int MoveY { get; set; }
    }
}
